import CouncilGrid from '@/components/CouncilGrid';
export default function Page() {
  return (
    <section className="container py-16">
      <h2 className="text-3xl font-bold mb-6">Councils</h2>
      <CouncilGrid />
    </section>
  );
}
