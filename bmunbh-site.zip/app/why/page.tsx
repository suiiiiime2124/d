export default function Page() {
  const items = [
    { title: 'Skill Building', body: 'Public speaking, diplomacy, research and leadership – all in one weekend.' },
    { title: 'Diverse Councils', body: 'Junior & Senior councils tailored to experience level and interest.' },
    { title: 'Awards Gala', body: 'Celebrate excellence at our closing ceremony and awards night.' },
  ];
  return (
    <section className="container py-16">
      <h2 className="text-3xl font-bold mb-6">Why participate in BMUN?</h2>
      <div className="grid md:grid-cols-3 gap-4">
        {items.map(it => (
          <div key={it.title} className="card">
            <div className="card-body">
              <div className="font-semibold mb-1">{it.title}</div>
              <p className="text-slate-700">{it.body}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
