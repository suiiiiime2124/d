export default function Page() {
  const address = [
    'Bhavans Bahrain Indian School',
    'P.O.Box: 31595, Building No: 109, Road: 7307, Block: 473',
    'Kingdom of Bahrain'
  ];
  return (
    <section className="container py-16">
      <h2 className="text-3xl font-bold mb-6">Contact</h2>
      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2 card">
          <div className="card-body space-y-3 text-slate-700">
            <p>Email: <a className="underline" href="mailto:bmun.bis@gmail.com">bmun.bis@gmail.com</a></p>
            <p>Instagram: <a className="underline" href="https://www.instagram.com/bmun.bis/" target="_blank">@bmun.bis</a></p>
            <p className="flex items-start gap-2">
              <span>
                {address[0]}<br/>{address[1]}<br/>{address[2]}
              </span>
            </p>
          </div>
        </div>
        <div className="card">
          <div className="card-body space-y-3">
            <a className="block underline" href="/">Official Website</a>
            <a className="block underline" href="/councils">Councils</a>
            <a className="block underline" href="/information">Information</a>
            <a className="block underline" href="/register">Registration</a>
            <a className="block underline" href="/contact">Contact</a>
          </div>
        </div>
      </div>
    </section>
  );
}
