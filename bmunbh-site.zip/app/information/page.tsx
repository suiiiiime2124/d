export default function Page() {
  const schedule = [
    { day: 'Day 1', date: 'Jan 3, 2025', attire: 'Indian formals', blocks: [
      ['08:30','09:00','Registration'],
      ['09:00','10:00','Opening Ceremony'],
      ['10:00','11:30','Committee Session 1'],
      ['11:30','11:45','Break'],
      ['11:45','13:00','Committee Session 2'],
      ['13:00','13:30','Lunch'],
      ['13:30','15:15','Committee Session 3'],
      ['15:15','15:30','High Tea'],
      ['15:30','17:00','Committee Session 4'],
    ]},
    { day: 'Day 2', date: 'Jan 4, 2025', attire: 'Western formals', blocks: [
      ['09:00','10:30','Committee Session 5'],
      ['10:30','10:45','Break'],
      ['10:45','12:15','Committee Session 6'],
      ['12:15','13:00','Lunch'],
      ['13:00','14:30','Committee Session 7'],
      ['14:45','16:30','Awards & Closing'],
    ]},
  ];
  return (
    <section className="container py-16">
      <h2 className="text-3xl font-bold mb-6">Information</h2>
      <div className="grid md:grid-cols-2 gap-6">
        {schedule.map(d => (
          <div key={d.day} className="card">
            <div className="card-body">
              <div className="flex items-center justify-between mb-3">
                <div className="font-semibold">{d.day} · {d.date}</div>
                <span className="badge">{d.attire}</span>
              </div>
              <ul className="space-y-2">
                {d.blocks.map(([s,e,w],i) => (
                  <li key={i} className="flex items-center justify-between gap-3 p-3 rounded-2xl border bg-white">
                    <div className="text-sm font-medium">{w}</div>
                    <div className="text-xs text-slate-500">{s}–{e}</div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>

      <div className="card mt-6">
        <div className="card-body space-y-2 text-slate-700">
          <div className="font-semibold">Important Notes</div>
          <p>• Early bird fee ends on <b>Sep 10, 2025</b>. Afterwards, standard fee applies.</p>
          <p>• Team delegations must ensure <b>both partners</b> complete registration before allocation is confirmed.</p>
          <p>• BIS applicants may register via physical forms when school reopens.</p>
        </div>
      </div>

    </section>
  );
}
