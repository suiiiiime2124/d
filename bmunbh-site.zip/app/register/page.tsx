import Link from 'next/link';
export default function Page() {
  return (
    <section className="container py-16 text-center">
      <h2 className="text-3xl font-bold mb-4">Ready to secure your spot?</h2>
      <p className="text-slate-700 mb-6">Complete the form on our official portal. You will receive a confirmation email after submission.</p>
      <Link href="https://bmunbh.com/register" className="btn btn-primary">Go to Registration</Link>
    </section>
  );
}
