import Link from 'next/link';
import Countdown from '@/components/Countdown';

export default function Page() {
  return (
    <section className="container py-16">
      <div className="grid md:grid-cols-2 gap-8 items-center">
        <div>
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight leading-tight">Bhavans Model United Nations</h1>
          <p className="mt-4 text-lg text-slate-700">Debate. Diplomacy. Direction. Join Bahrain's most exciting student conference and sharpen skills that last a lifetime.</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link href="/register" className="btn btn-primary">Register Now</Link>
            <Link href="/councils" className="btn btn-outline">Explore Councils</Link>
          </div>
          <div className="mt-8">
            <div className="mb-2 text-sm text-slate-600">Countdown to Conference</div>
            <Countdown target="2025-11-21T08:30:00+03:00" />
          </div>
        </div>
        <div>
          <div className="relative aspect-[4/3] rounded-3xl bg-gradient-to-br from-slate-800 to-slate-900 shadow-xl overflow-hidden">
            <div className="grid grid-cols-3 grid-rows-3 gap-1 p-3 h-full">
              {Array.from({ length: 9 }).map((_, i) => (<div key={i} className="rounded-xl bg-white/5 border border-white/10" />))}
            </div>
            <div className="absolute bottom-3 right-3 badge text-slate-100 bg-white/10 border border-white/20">BMUN'25</div>
          </div>
        </div>
      </div>
    </section>
  );
}
