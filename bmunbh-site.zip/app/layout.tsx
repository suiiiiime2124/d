import './globals.css';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import Nav from '@/components/Nav';
import Footer from '@/components/Footer';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: "BMUN'25 — Bhavans Model United Nations, Bahrain",
  description: "Debate. Diplomacy. Direction. Bahrain's most exciting student MUN conference.",
  openGraph: { title: "BMUN'25", description: "Bahrain MUN Conference", type: 'website' }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Nav />
        <main className="pt-28">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
