# BMUNBH — Next.js + Tailwind Site

## Local setup
```bash
# 1) Extract and enter
unzip bmunbh-site.zip
cd bmunbh-site

# 2) Install deps
npm install

# 3) Dev server
npm run dev
# Open http://localhost:3000

# 4) Production build
npm run build
npm start
```

## Deploy (Vercel)
1. Create a new GitHub repo and push this folder.
2. Go to Vercel ➜ New Project ➜ Import repo ➜ Framework: **Next.js** ➜ Deploy.
3. Set a custom domain (e.g., `bmunbh.com`) in Vercel Domains.

## Edit content
- Pages live in `/app`.
- Components in `/components`.
- Global styles in `/styles/globals.css` + `/app/globals.css`.

## Notes
- Tailwind and TypeScript included.
- No external UI kit required; all styles are Tailwind-based.
- Countdown target is set in `/app/page.tsx`.
- Update schedule/fees in `/app/information/page.tsx`.
- Update councils in `/components/CouncilGrid.tsx`.
