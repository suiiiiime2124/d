/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#eef6ff",
          100: "#d9eaff",
          200: "#b5d5ff",
          300: "#88bbff",
          400: "#5699ff",
          500: "#2f7dff",
          600: "#1c63e6",
          700: "#154dc0",
          800: "#133f99",
          900: "#122f6b"
        }
      }
    },
  },
  plugins: [],
};
