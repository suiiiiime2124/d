'use client';
import { useEffect, useState } from 'react';

function pad2(n:number){ return n.toString().padStart(2,'0'); }

export default function Countdown({ target }: { target: string }) {
  const [left, setLeft] = useState<number>(0);
  useEffect(() => {
    const t = new Date(target).getTime();
    const tick = () => setLeft(Math.max(0, t - Date.now()));
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [target]);
  const s = Math.floor(left / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return (
    <div className="grid grid-flow-col auto-cols-max gap-3 text-center">
      {[['Days', d], ['Hours', h], ['Minutes', m], ['Seconds', sec]].map(([label, val]) => (
        <div key={String(label)} className="card">
          <div className="card-body">
            <div className="text-3xl font-bold tabular-nums">{pad2(Number(val))}</div>
            <div className="text-xs text-slate-500">{String(label)}</div>
          </div>
        </div>
      ))}
    </div>
  );
}
