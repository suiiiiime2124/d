'use client';
import Link from 'next/link';
import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

export default function Nav() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 8);
    h();
    addEventListener('scroll', h, { passive: true });
    return () => removeEventListener('scroll', h);
  }, []);
  const links = [
    { href: '/', label: 'Home' },
    { href: '/why', label: 'Why BMUN' },
    { href: '/councils', label: 'Councils' },
    { href: '/information', label: 'Information' },
    { href: '/register', label: 'Register' },
    { href: '/contact', label: 'Contact' },
  ];
  return (
    <div className={`fixed top-0 inset-x-0 z-50 border-b backdrop-blur ${scrolled ? 'shadow-sm bg-white/70' : 'border-transparent'}`}>
      <nav className="container py-3 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-2xl bg-slate-900 text-white grid place-content-center font-semibold">BM</div>
          <div className="font-semibold">BMUN'25</div>
        </Link>
        <div className="hidden md:flex items-center gap-1 nav link">
          {links.map(l => (
            <Link key={l.href} href={l.href}>{l.label}</Link>
          ))}
          <Link href="/register" className="btn btn-primary ml-1">Register</Link>
        </div>
        <button className="md:hidden btn btn-outline" onClick={() => setOpen(v=>!v)}>{open ? <X width={18}/> : <Menu width={18}/>}</button>
      </nav>
      {open && (
        <div className="md:hidden border-t bg-white/90">
          <div className="container py-2 grid gap-1">
            {links.map(l => (
              <Link key={l.href} href={l.href} onClick={()=>setOpen(false)} className="px-3 py-2 rounded-2xl hover:bg-slate-100">{l.label}</Link>
            ))}
            <Link href="/register" onClick={()=>setOpen(false)} className="btn btn-primary mt-2 text-center">Register</Link>
          </div>
        </div>
      )}
    </div>
  );
}
