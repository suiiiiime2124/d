export default function Footer() {
  return (
    <footer className="mt-12 border-t">
      <div className="container py-6 text-sm text-slate-600 flex flex-col md:flex-row items-center justify-between gap-3">
        <span>© 2025 BMUN. All rights reserved.</span>
        <span>Kingdom of Bahrain</span>
      </div>
    </footer>
  );
}
