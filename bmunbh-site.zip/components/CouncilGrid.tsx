'use client';
import { useMemo, useState } from 'react';

const JUNIOR = [
  { name: 'UNICEF', blurb: 'Child rights & development', seats: 40 },
  { name: 'UNEP', blurb: 'Environment & sustainability', seats: 40 },
];
const SENIOR = [
  { name: 'UNSC', blurb: 'Peace & security agenda', seats: 30 },
  { name: 'DISEC', blurb: 'Disarmament & international security', seats: 40 },
  { name: 'ECOSOC', blurb: 'Economic & social policy', seats: 40 },
  { name: 'HCC', blurb: 'Historical crisis committee', seats: 25 },
];

export default function CouncilGrid() {
  const [q, setQ] = useState('');
  const re = useMemo(() => new RegExp(q, 'i'), [q]);
  const F = (arr:any[]) => arr.filter(c => re.test(c.name) || re.test(c.blurb));
  return (
    <div className="space-y-6">
      <input
        value={q}
        onChange={e=>setQ(e.target.value)}
        placeholder="Search councils…"
        className="w-full md:w-80 rounded-2xl border px-4 py-2"
      />
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="card">
          <div className="card-body">
            <div className="font-semibold mb-3">Junior Councils <span className="badge ml-2">BIS only</span></div>
            <div className="grid sm:grid-cols-2 gap-4">
              {F(JUNIOR).map(c => (
                <div key={c.name} className="p-4 rounded-2xl border bg-white shadow-sm">
                  <div className="font-semibold">{c.name}</div>
                  <div className="text-sm text-slate-600">{c.blurb}</div>
                  <div className="mt-2 text-xs text-slate-500">Seats: {c.seats}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="card">
          <div className="card-body">
            <div className="font-semibold mb-3">Senior Councils</div>
            <div className="grid sm:grid-cols-2 gap-4">
              {F(SENIOR).map(c => (
                <div key={c.name} className="p-4 rounded-2xl border bg-white shadow-sm">
                  <div className="font-semibold">{c.name}</div>
                  <div className="text-sm text-slate-600">{c.blurb}</div>
                  <div className="mt-2 text-xs text-slate-500">Seats: {c.seats}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
